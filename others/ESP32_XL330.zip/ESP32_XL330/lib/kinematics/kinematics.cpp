#include "kinematics.h"


const float r = 50;     //轮半径，单位 mm
const float L1 = r;     // 大腿长度
const float L2 = r*sqrt(3);  // 小腿长度


//运动学逆解
float* ikine(float x,float y)
{
    float alpha, beta;
    float L3;
    static float angle[2];

    L3 = sqrt(x*x + y*y);
    alpha = acos(x / L3);

    beta = acos((L1*L1 + L3*L3 - L2*L2) / (2*L1*L3));

    angle[0] = alpha - beta + PI/2;
    angle[1] = alpha + beta + PI/2;

    // 这里改了一下，防止减小2PI到负值
    // if(angle[0] < 0){
    //     angle[0] += 2*PI;
    // }
    // angle[0] = angle[0] + PI/3;     // PI/3，即60度，轮模式的角度差

    return angle;           //angle[0]外电机,angle[1]内电机
}