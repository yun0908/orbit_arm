#ifndef KINEMATICS_H_
#define KINEMATICS_H_


#include <math.h>
#include <Arduino.h>


//端点运动学逆解，[motor1, motor0]
float* ikine(float x,float y);


#endif