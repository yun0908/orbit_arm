#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include <Arduino.h>
#include <Dynamixel2Arduino.h>
#include "ESP32SerialPortHandler.h"
#include "kinematics.h"
#include <Arduino.h>

// using namespace ControlTableItem;
#define DEBUG_SERIAL                Serial

#define DXL_ID_CNT                  8
#define BROADCAST_ID                254
#define USER_PKT_BUF_CAP            256
#define DXL_PROTOCOL_VERSION        2.0
#define DXL_SERIAL                  Serial1
#define DXL_DIR_PIN                 4       // DIR pin
#define DXL_RX_PIN                  16      // RX pin
#define DXL_TX_PIN                  17      // TX pin
#define BAUDATE                     1000000

#define ADDR_GOAL_POSITION          116
#define ADDR_GOAL_VELOCITY          104
#define ADDR_GOAL_CURRENT           102
#define ADDR_HOMING_OFFSET          20


#define ADDR_PRESENT_PODITION       132
#define ADDR_PRESENT_VELOCITY       128
#define ADDR_PRESENT_CURRENT        126
#define ADDR_PROFILE_VELOCITY       112

#define ADDR_LEN_HOMING_OFFSET      4
#define ADDR_LEN_POSITION           4
#define ADDR_LEN_VELOCITY           4
#define ADDR_LEN_CURRENT            2
#define ADDR_LEN_PROFILE_VELOCITY   4
#define ADDR_LEN_HOMING_OFFSET      4


// 同步读数据结构类型
typedef struct sr_data{
    int32_t profile_velocity;
    int16_t present_current;
    int32_t present_velocity;
    int32_t present_position;
    int32_t homing_offset;
} __attribute__((packed)) sr_data_t;

// 同步写数据结构类型
typedef struct sw_data{
    int16_t goal_current;
    int32_t goal_velocity;
    int32_t goal_position;
    int32_t profile_velocity;
    int32_t homing_offset;
} __attribute__((packed)) sw_data_t;


// 腿模式步态
typedef struct leg_parameter
{
    float step_len;         // 步长
    float step_h_forward;   // 向前迈的摆线的高度
    float step_h_backward;  // 向后迈的摆线的高度
    float step_H;           // 摆线在y轴方向的偏移
    float T;                // 周期
    float start;            // 后着地点
    float end;              // 前着地点
}leg_parameter_t;


void init_controller(void);

void switch_to_postion_mode(void);
void switch_to_extend_position_mode(void);
void switch_to_velocity_mode(void);

void set_target_position(int32_t pos[DXL_ID_CNT]);
void set_target_velocity(int32_t vel[DXL_ID_CNT]);
void set_profile_velocity(int32_t pro_vel);


int32_t *get_profile_velocity(void);
void get_present_position(int32_t *pre_position);

void reset_homing_offset(void);
void set_homing_offset(void);

// void test(void);
void leg_init_posture(void);
void trot(unsigned int durt);
void leg_test(void);
void test(void);
// void trot(unsigned int start);
void finish(void);

#endif