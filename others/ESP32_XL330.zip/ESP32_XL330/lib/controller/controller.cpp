#include "controller.h"



const uint8_t ID_LIST[DXL_ID_CNT] = {0, 1, 2, 3, 4, 5, 6, 7}; 
uint8_t user_pkt_buf[USER_PKT_BUF_CAP];

float *angle;
float angles[8];
int32_t goal_position[DXL_ID_CNT];

// 同步读取数据类型
sr_data_t sr_data[DXL_ID_CNT];
DYNAMIXEL::InfoSyncReadInst_t sr_infos;
DYNAMIXEL::XELInfoSyncRead_t info_xels_sr[DXL_ID_CNT];

// std::shared_ptr<sr_data_t> p_sr_data = std::make_shared<sr_data_t>(sr_data[DXL_ID_CNT]);
// std::shared_ptr<DYNAMIXEL::InfoSyncReadInst_t> p_sr_info = std::make_shared<DYNAMIXEL::InfoSyncReadInst_t>(sr_infos);
// std::shared_ptr<DYNAMIXEL::XELInfoSyncRead_t> p_info_xels_sr = std::make_shared<DYNAMIXEL::XELInfoSyncRead_t>(info_xels_sr[DXL_ID_CNT]);

// 同步写入数据类型
sw_data_t sw_data[DXL_ID_CNT];
DYNAMIXEL::InfoSyncWriteInst_t sw_infos;
DYNAMIXEL::XELInfoSyncWrite_t info_xels_sw[DXL_ID_CNT];

// 腿模式运动参数
leg_parameter_t leg_parameter;

// New way of creating dxl
Dynamixel2Arduino dxl;

// Our custom handler with RX and TX pins specified.
ESP32SerialPortHandler esp_dxl_port(DXL_SERIAL, DXL_RX_PIN, DXL_TX_PIN, DXL_DIR_PIN);


void init_controller(void)
{
    // Set custom port handler
    dxl.setPort(esp_dxl_port);
    dxl.begin(BAUDATE);
    // Set Port Protocol Version. This has to match with DYNAMIXEL protocol version.
    dxl.setPortProtocolVersion(DXL_PROTOCOL_VERSION);

    // Fill the members of structure to syncRead using external user packet buffer
    sr_infos.packet.p_buf = user_pkt_buf;
    sr_infos.packet.buf_capacity = USER_PKT_BUF_CAP;
    sr_infos.packet.is_completed = false;
    sr_infos.addr = ADDR_PROFILE_VELOCITY;
    sr_infos.addr_length = 4;
    sr_infos.p_xels = info_xels_sr;
    sr_infos.xel_count = 0;  

    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        info_xels_sr[i].id = ID_LIST[i];
        info_xels_sr[i].p_recv_buf = (uint8_t*)&sr_data[i]; 
        sr_infos.xel_count++;
    }
    sr_infos.is_info_changed = true;

    // Fill the members of structure to syncWrite using internal packet buffer
    sw_infos.packet.p_buf = nullptr;
    sw_infos.packet.is_completed = false;
    sw_infos.addr = ADDR_GOAL_POSITION;
    sw_infos.addr_length = ADDR_LEN_POSITION;
    sw_infos.p_xels = info_xels_sw;
    sw_infos.xel_count = 0;

    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        info_xels_sw[i].id = ID_LIST[i];
        info_xels_sw[i].p_data = (uint8_t*)&sw_data[i].goal_position;
        sw_infos.xel_count++;
    }
    sw_infos.is_info_changed = true;

    Serial.println("init success!!!");

    leg_parameter.T = 1;
    leg_parameter.step_len = 40;
    leg_parameter.step_H = 100;
    leg_parameter.start = -1*leg_parameter.step_len/2;
    leg_parameter.end = leg_parameter.step_len/2;
    leg_parameter.step_h_forward = 35;
}

/**
 * 
*/
void switch_to_postion_mode(void)
{
    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        dxl.torqueOff(i);
        dxl.setOperatingMode(i, OP_POSITION);
    }
    if(dxl.torqueOn(BROADCAST_ID))
    {
        Serial.println("switch success!!");
    }

}


void switch_to_extend_position_mode(void)
{
    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        dxl.torqueOff(i);
        dxl.setOperatingMode(i, OP_EXTENDED_POSITION);
    }
    if(dxl.torqueOn(BROADCAST_ID))
    {
        Serial.println("switch success!!");
    }
}

void switch_to_velocity_mode(void)
{
    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        dxl.torqueOff(i);
        dxl.setOperatingMode(i, OP_VELOCITY);
    }
    if(dxl.torqueOn(BROADCAST_ID))
    {
        Serial.println("switch success!!");
    }

    sw_infos.addr = ADDR_GOAL_VELOCITY;
    sw_infos.addr_length = ADDR_LEN_VELOCITY;

    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        info_xels_sw[i].p_data = (uint8_t*)&sw_data[i].goal_velocity;
    }
}

void set_target_position(int32_t pos[DXL_ID_CNT])
{
    for(uint8_t i = 0; i < DXL_ID_CNT; i++){
        sw_data[i].goal_position = pos[i];
    }
    sw_infos.is_info_changed = true;
    if(dxl.syncWrite(&sw_infos))
    {
        Serial.println("write success!!!");
    }
    else
    {
        DEBUG_SERIAL.print("[SyncWrite] Fail, Lib error code: ");
        DEBUG_SERIAL.print(dxl.getLastLibErrCode());
    }
}


void set_target_velocity(int32_t vel[DXL_ID_CNT])
{
    for(uint8_t i = 0; i < DXL_ID_CNT; i++){
        sw_data[i].goal_velocity = vel[i];
    }
    sw_infos.is_info_changed = true;
    if(dxl.syncWrite(&sw_infos))
    {
        Serial.println("write success!!!");
    }
    else
    {
        DEBUG_SERIAL.print("[SyncWrite] Fail, Lib error code: ");
        DEBUG_SERIAL.print(dxl.getLastLibErrCode());
    }
}

void get_present_position(int32_t *pre_position)
{
    sr_infos.addr = ADDR_PRESENT_PODITION;
    sr_infos.addr_length = ADDR_LEN_POSITION;
    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        info_xels_sr[i].p_recv_buf = (uint8_t*)&sr_data[i].present_position; 
    }
    uint8_t recv_cnt = dxl.syncRead(&sr_infos);
    if(recv_cnt > 0){
        for(uint8_t i=0; i < DXL_ID_CNT; i++)
        {
            DEBUG_SERIAL.print("  ID: ");DEBUG_SERIAL.print(sr_infos.p_xels[i].id);
            DEBUG_SERIAL.print("\t Present Position: ");DEBUG_SERIAL.println(sr_data[i].present_position);
            pre_position[i] = sr_data[i].present_position;
        }
    }
    else
    {
        DEBUG_SERIAL.print("[SyncRead] Fail, Lib error code: ");
        DEBUG_SERIAL.println(dxl.getLastLibErrCode());
    }
}


void set_profile_velocity(int32_t pro_vel)
{
    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        dxl.writeControlTableItem(ControlTableItem::PROFILE_VELOCITY, ID_LIST[i], pro_vel);
    }
}


int32_t *get_profile_velocity(void)
{
    sr_infos.addr = ADDR_PROFILE_VELOCITY;
    sr_infos.addr_length = ADDR_LEN_PROFILE_VELOCITY;
    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        info_xels_sr[i].p_recv_buf = (uint8_t*)&sr_data[i].profile_velocity; 
    }
    uint8_t recv_cnt = dxl.syncRead(&sr_infos);
    int32_t ret_list[DXL_ID_CNT];
    if(recv_cnt > 0){
        for(uint8_t i=0; i<DXL_ID_CNT; i++)
        {
            ret_list[i] = sr_data[i].profile_velocity;
        }
    }
    else{
        DEBUG_SERIAL.print("[SyncRead] Fail, Lib error code: ");
        DEBUG_SERIAL.println(dxl.getLastLibErrCode());
    }
    return ret_list;
}


void reset_homing_offset(void)
{
    int32_t homing_offset_value[DXL_ID_CNT] = {0, 0, 0, 0, 0, 0, 0, 0};

    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        dxl.torqueOff(i);
        dxl.writeControlTableItem(ControlTableItem::HOMING_OFFSET, ID_LIST[i], homing_offset_value[i]);
    }
    if(dxl.torqueOn(BROADCAST_ID))
    {
        Serial.println("switch success!!");
    }
    delay(100);
}

//设置当前电机为初始位置
void set_homing_offset(void)
{
    int32_t present_position[DXL_ID_CNT];
    int32_t homing_offset_value[DXL_ID_CNT] = {3413, 682, 3413, 682, 682, 3413, 682, 3413};
    get_present_position(present_position);

    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        homing_offset_value[i] -= present_position[i];
    }

    for(uint8_t i = 0; i < DXL_ID_CNT; i++)
    {
        dxl.torqueOff(i);
        dxl.writeControlTableItem(ControlTableItem::HOMING_OFFSET, ID_LIST[i], homing_offset_value[i]);
    }
    if(dxl.torqueOn(BROADCAST_ID))
    {
        Serial.println("switch success!!");
    }
    delay(100);
}


void leg_test(void)
{
    int32_t pre_position[DXL_ID_CNT];
    int32_t goal_position[DXL_ID_CNT];
    angle = ikine(0, 80);
    DEBUG_SERIAL.printf("angle0 : %f, angle1 : %f\r\n", angle[0], angle[1]);
    for(uint8_t i = 0; i < 4; i++)
    {
        if(i < 2){
            goal_position[2*i] = (uint32_t)(angle[1] / PI * 2048);
            goal_position[2*i+1] = (uint32_t)(angle[0] / PI * 2048);
        }else
        {
            goal_position[2*i] = (uint32_t)(angle[0] / PI * 2048);
            goal_position[2*i+1] = (uint32_t)(angle[1] / PI * 2048);
        }
    }
    set_target_position(goal_position);
}


void leg_init_posture(void)
{

    float x_set, y_set;
    // 左腿前迈
    x_set = leg_parameter.start;
    y_set = leg_parameter.step_H;
    angle = ikine(x_set, y_set);
    for(uint8_t i = 0; i < 4; i+=2)
    {
        angles[2*i] = angle[0];
        angles[2*i+1] = angle[1];
    }

    // 右腿后迈
    x_set = leg_parameter.end;
    y_set = leg_parameter.step_H;
    angle = ikine(x_set, y_set);
    for(uint8_t i = 1; i < 4; i+=2)
    {
        angles[2*i] = angle[0];
        angles[2*i+1] = angle[1];
    }
    for(uint8_t i = 0; i < 4; i++)
    {
        if(i < 2){
            goal_position[2*i] = (uint32_t)(angles[2*i+1] / PI * 2048);
            goal_position[2*i+1] = (uint32_t)(angles[2*i] / PI * 2048);
        }else
        {
            goal_position[2*i] = (uint32_t)(angles[2*i] / PI * 2048);
            goal_position[2*i+1] = (uint32_t)(angles[2*i+1] / PI * 2048);
        }
    }

    for(uint8_t i = 0; i < 4; i++)
    {
        DEBUG_SERIAL.printf("angle0 : %f, angle1 : %f\r\n", angles[2*i], angles[2*i+1]);
    }
    set_target_position(goal_position);
}

void trot(unsigned int durt)
{
    unsigned long start_time = millis();
    unsigned long t;
    float t_cycle;
    float x_set, y_set;
    unsigned long T= leg_parameter.T*1000;
    t = millis() - start_time;

    while(t < durt)
    {
        //使用取余函数
        t_cycle = ((float)(t%T)/1000);
        DEBUG_SERIAL.printf("t_cycle : %f\r\n", t_cycle);
        if(t_cycle < leg_parameter.T/2)
        {
            // 左腿前迈
            x_set = leg_parameter.start + (2*t_cycle/leg_parameter.T) * leg_parameter.step_len;
            y_set = (-1)*leg_parameter.step_h_forward * cos(x_set/(leg_parameter.step_len/2)*PI/2) + leg_parameter.step_H;
            angle = ikine(x_set, y_set);
            for(uint8_t i = 0; i < 4; i+=2)
            {
                angles[2*i] = angle[0];
                angles[2*i+1] = angle[1];
            }
            // 右腿后迈
            x_set = leg_parameter.end - (2*t_cycle/leg_parameter.T) * leg_parameter.step_len;
            y_set = leg_parameter.step_H;
            angle = ikine(x_set, y_set);
            for(uint8_t i = 1; i < 4; i+=2)
            {
                angles[2*i] = angle[0];
                angles[2*i+1] = angle[1];
            }
        }   
        else
        {
            // 左腿后迈
            x_set = leg_parameter.end - (2*t_cycle/leg_parameter.T -1) * leg_parameter.step_len;
            y_set = leg_parameter.step_H;
            angle = ikine(x_set, y_set);
            for(uint8_t i = 0; i < 4; i+=2)
            {
                angles[2*i] = angle[0];
                angles[2*i+1] = angle[1];
            }
            
            // 右腿前迈
            x_set = leg_parameter.start + (2*t_cycle/leg_parameter.T - 1) * leg_parameter.step_len;
            y_set = (-1)*leg_parameter.step_h_forward * cos(x_set/(leg_parameter.step_len/2)*PI/2) + leg_parameter.step_H;
            angle = ikine(x_set, y_set);
            for(uint8_t i = 1; i < 4; i+=2)
            {
                angles[2*i] = angle[0];
                angles[2*i+1] = angle[1];
            }
        }

        for(uint8_t i = 0; i < 4; i++)
        {
            if(i < 2){
                goal_position[2*i] = (uint32_t)(angles[2*i+1] / PI * 2048);
                goal_position[2*i+1] = (uint32_t)(angles[2*i] / PI * 2048);
            }else
            {
                goal_position[2*i] = (uint32_t)(angles[2*i] / PI * 2048);
                goal_position[2*i+1] = (uint32_t)(angles[2*i+1] / PI * 2048);
            }
        }
        set_target_position(goal_position);
        delay(10);
        t = millis() - start_time;
    }
}

// void trot(unsigned int start)
// {
//     unsigned long t;
//     float t_cycle;
//     t = millis() - start;
//     float x_set, y_set;
//     unsigned long T= leg_parameter.T*1000;
//     //使用取余函数
//     t_cycle = (float)((t%T)/1000);
//     DEBUG_SERIAL.printf("t_cycle : %d\r\n", t_cycle);
//     if(t_cycle < leg_parameter.T/2)
//     {
//         // 左腿前迈
//         x_set = leg_parameter.start + (t_cycle/leg_parameter.T) * leg_parameter.step_len;
//         y_set = leg_parameter.step_h_forward * cos(x_set/(leg_parameter.step_len/2)*PI/2) + leg_parameter.step_H;
//         angle = ikine(x_set, y_set);
//         for(uint8_t i = 0; i < 4; i+=2)
//         {
//             angles[2*i] = angle[0];
//             angles[2*i+1] = angle[1];
//         }
//         DEBUG_SERIAL.printf("x_set : %f, y_set : %f\r\n", x_set, y_set);
//         DEBUG_SERIAL.printf("angle0 : %f, angle1 : %f\r\n", angle[0], angle[1]);
//         // 右腿后迈
//         x_set = leg_parameter.end - (t_cycle/leg_parameter.T) * leg_parameter.step_len;
//         y_set = leg_parameter.step_H;
//         angle = ikine(x_set, y_set);
//         for(uint8_t i = 1; i < 4; i+=2)
//         {
//             angles[2*i] = angle[0];
//             angles[2*i+1] = angle[1];
//         }
//     }   
//     else
//     {
//         // 左腿后迈
//         x_set = leg_parameter.end - (1 - t_cycle/leg_parameter.T) * leg_parameter.step_len;
//         y_set = leg_parameter.step_H;
//         angle = ikine(x_set, y_set);
//         for(uint8_t i = 0; i < 4; i+=2)
//         {
//             angles[2*i] = angle[0];
//             angles[2*i+1] = angle[1];
//         }

//         // 右腿前迈
//         x_set = leg_parameter.start + (1 - t_cycle/leg_parameter.T) * leg_parameter.step_len;
//         y_set = leg_parameter.step_h_forward * cos(x_set/(leg_parameter.step_len/2)*PI/2) + leg_parameter.step_H;
//         for(uint8_t i = 1; i < 4; i+=2)
//         {
//             angles[2*i] = angle[0];
//             angles[2*i+1] = angle[1];
//         }
//     }

//     for(uint8_t i = 0; i < 4; i++)
//     {
//         if(i < 2){
//             goal_position[2*i] = (uint32_t)(angles[2*i+1] / PI * 2048);
//             goal_position[2*i+1] = (uint32_t)(angles[2*i] / PI * 2048);
//         }else
//         {
//             goal_position[2*i] = (uint32_t)(angles[2*i] / PI * 2048);
//             goal_position[2*i+1] = (uint32_t)(angles[2*i+1] / PI * 2048);
//         }
//     }
//     for(uint8_t i = 0; i < 4; i++)
//     {
//         DEBUG_SERIAL.printf("pos0 : %d, pos1 : %d\r\n", goal_position[2*i], goal_position[2*i+1]);
//     }
//     set_target_position(goal_position);
//     delay(20);
//     DEBUG_SERIAL.printf("t : %d\r\n", t);
// }

void test(void)
{
    if(dxl.ping(0))
    {
        DEBUG_SERIAL.printf("motor1 ping success\r\n");
    }
    else{
        DEBUG_SERIAL.printf("failed\r\n");
    }
}

void finish(void)
{
    if(dxl.torqueOff(BROADCAST_ID))
    {
        Serial.println("finish!!!");
    }
}