#include "robot.h"



Robot::Robot()
{
    present_positon.resize(DXL_ID_CNT);
    present_velocity.resize(DXL_ID_CNT);
}


void Robot::init(void)
{
    setPortProtocolVersion(DXL_PROTOCOL_VERSION);
    for(int i = 0; i < DXL_ID_CNT; i++)
    {
        torqueOff(i);
        setOperatingMode(i, OP_POSITION);
    }
    if(torqueOn(BROADCAST_ID))
    {
        Serial.println("init success!!");
    }

}


void Robot::setTargetPositionMode(DYNAMIXEL::InfoSyncWriteInst_t* p_sw_info, sw_data_t* p_sw_date, 
                                DYNAMIXEL::XELInfoSyncWrite_t* p_info_xels_sw)
{
    p_sw_info->addr = ADDR_GOAL_POSITION;
    p_sw_info->addr_length = ADDR_LEN_POSITION;

    for(int i =0 ; i < DXL_ID_CNT; i++)
    {
        (p_info_xels_sw + i)->id = ID_LIST[i];
        (p_info_xels_sw + i)->p_data = (uint8_t*)&(p_sw_date + i)->goal_position;
        p_sw_info->xel_count++;
    }
    p_sw_info->is_info_changed = true;
}

void Robot::setTargetPosition(DYNAMIXEL::InfoSyncWriteInst_t* p_sw_info, sw_data_t* p_sw_date, int32_t t_pos[DXL_ID_CNT])
{
    for(int i = 0; i < DXL_ID_CNT; i++)
    {
        (p_sw_date + i)->goal_position = t_pos[i];
    }
    p_sw_info->is_info_changed = true;

    syncWrite(p_sw_info);
}

// std::vector<int32_t> Robot::getPresentPosition(void)
// {

// }

// bool Robot::switchMode(uint8_t mode)
// {
//     for(int i = 0; i < DXL_ID_CNT; i++)
//     {
//         torqueOff(i);
//         setOperatingMode(i, mode);
//     }
//     if(torqueOn(BROADCAST_ID))
//     {
//         Serial.println("switch success!!");
//         return true;
//     }
//     else{
//         return false;
//     }
// }

// void Robot::setTargetVelocity(std::vector<int32_t> t_vel)
// {
    
// }

