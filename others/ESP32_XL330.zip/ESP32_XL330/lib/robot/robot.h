#ifndef ROBOT_H_
#define ROBOT_H_

#include <Arduino.h>
#include <Dynamixel2Arduino.h>
#include "ESP32SerialPortHandler.h"
#include <vector>


using namespace ControlTableItem;


#define DXL_ID_CNT              2
#define BROADCAST_ID            254
#define USER_PKT_BUF_CAP        256
#define DXL_PROTOCOL_VERSION    2.0
#define DXL_SERIAL              Serial1
#define DXL_DIR_PIN             4       // DIR pin
#define DXL_RX_PIN              16      // RX pin
#define DXL_TX_PIN              17      // TX pin
#define BAUDATE                 115200



#define ADDR_GOAL_POSITION          116
#define ADDR_GOAL_VELOCITY          104
#define ADDR_GOAL_CURRENT           102
#define ADDR_PRESENT_PODITION       132
#define ADDR_PRESENT_VELOCITY       128
#define ADDR_PRESENT_CURRENT        126

#define ADDR_LEN_POSITION           4
#define ADDR_LEN_VELOCITY           4
#define ADDR_LEN_CURRENT            2

// 同步读数据结构类型
typedef struct sr_data{
    int16_t present_current;
    int32_t present_velocity;
    int32_t present_position;
} __attribute__((packed)) sr_data_t;

// 同步写数据结构类型
typedef struct sw_data{
    int16_t goal_current;
    int32_t goal_velocity;
    int32_t goal_position;
} __attribute__((packed)) sw_data_t;


class  Robot : public Dynamixel2Arduino
{
private:
    /* data */

    std::vector<int32_t> present_positon;
    std::vector<int32_t> present_velocity;
    std::vector<int16_t> present_current;


public:
    const uint8_t ID_LIST[DXL_ID_CNT] = {0, 1};

    void init(void);

    void setTargetPositionMode(DYNAMIXEL::InfoSyncWriteInst_t* p_sw_info, sw_data_t* p_sw_date, 
                            DYNAMIXEL::XELInfoSyncWrite_t* p_info_xels_sw);
    void setTargetPosition(DYNAMIXEL::InfoSyncWriteInst_t* p_sw_info, sw_data_t* p_sw_date, 
                            int32_t t_pos[DXL_ID_CNT]);
    std::vector<int32_t> getPresentPosition(void);
    void setTargetVelocity(std::vector<int32_t> t_vel);
    std::vector<int32_t> getPresentVelocity(void);
    void setTargetCurrent(std::vector<int16_t> t_cur);
    std::vector<int16_t> getPresentCurrent(void);
    bool switchMode(uint8_t mode);

     Robot(/* args */);

};



#endif
