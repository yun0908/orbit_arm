#ifndef ESP32SERIALPORTHANDLER_H_

#define ESP32SERIALPORTHANDLER_H_

#include <Dynamixel2Arduino.h>

class ESP32SerialPortHandler : public DYNAMIXEL::SerialPortHandler
{
public:
    ESP32SerialPortHandler(HardwareSerial& port, int rx_pin = -1, int tx_pin = -1, const int dir_pin = -1);

    virtual void begin(unsigned long baud) override;
    
private:
    HardwareSerial& port_;
    unsigned long baud_;
    const int dir_pin_;
    int rx_pin_;
    int tx_pin_;
};


#endif
