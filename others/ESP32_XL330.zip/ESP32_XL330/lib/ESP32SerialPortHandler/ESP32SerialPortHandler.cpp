#include "ESP32SerialPortHandler.h"

ESP32SerialPortHandler::ESP32SerialPortHandler(HardwareSerial& port, int rx_pin, int tx_pin, const int dir_pin)
  : SerialPortHandler(port, dir_pin), port_(port), dir_pin_(dir_pin)
  {
      rx_pin_ = rx_pin;
      tx_pin_ = tx_pin;
  }

void ESP32SerialPortHandler::begin(unsigned long baud)
{
  baud_ = baud;
      if ( getOpenState() ) {
        // Already open, so just update baud rate.
        port_.updateBaudRate(baud_);
      } else {
        // If port_.begin(...) were called again, esp32 could lock up.
        port_.begin(baud_, SERIAL_8N1, rx_pin_, tx_pin_);
      }

      // From robitis example code.  Set default RX/TX direction.
      if (dir_pin_ != -1) {
        pinMode(dir_pin_, OUTPUT);
        digitalWrite(dir_pin_, LOW);
        while (digitalRead(dir_pin_) != LOW);
      }

      setOpenState(true);
}
