#include <Arduino.h>
#include <Dynamixel2Arduino.h>
#include "ESP32SerialPortHandler.h"
// #include "robot.h"
#include <vector>
#include <string>
#include <memory>
#include "controller.h"
#include "kinematics.h"
// Debug messages will appear on USB/serial monitor connection.
#define DEBUG_SERIAL Serial


int32_t pos[DXL_ID_CNT];
int32_t vel[DXL_ID_CNT] = {100, 100, 100, 100, 100, 100, 100, 100};
int32_t vel_0[DXL_ID_CNT] = {0, 0, 0, 0, 0, 0, 0, 0};
int32_t pro_vel[DXL_ID_CNT] = {100, 100, 100, 100, 100, 100, 100, 100};

float leg_pos[2] = {-30, 70};
// std::shared_ptr<sw_data_t> p_sw_data;
// std::shared_ptr<DYNAMIXEL::InfoSyncWriteInst_t> p_sw_info;
// std::shared_ptr<DYNAMIXEL::XELInfoSyncWrite_t> p_info_xels_s2;


unsigned long startTime;

void setup() {

  // Use UART port of DYNAMIXEL Shield to debug.
  DEBUG_SERIAL.begin(115200);   //set debugging port baudrate to 115200bps

  init_controller();
  delay(100);
  switch_to_extend_position_mode();

  // test();
  reset_homing_offset();
  set_homing_offset();
  // set_profile_velocity(100);

  get_present_position(pos);
  delay(100);
  leg_init_posture();  
  delay(1000);
  // set_target_position(pos);
  
  // switch_to_velocity_mode();
  // set8477_target_velocity(vel);

  // set_profile_velocity(100);
  
  // change(&sw_infos, sr_data);
  // leg_test();
  // switch_to_velocity_mode();
  // set_target_velocity(vel);
  // delay(20000);
  // set_target_velocity(vel_0);
  // switch_to_extend_position_mode();
  trot(10000);
  // startTime = millis();
  // delay(1000);
  finish();
}


void loop() {
  // put your main code here, to run repeatedly:
   // put your main code here, to run repeatedly:
  

  // get_present_position(pos);
  // get_profile_velocity();
  // DEBUG_SERIAL.printf("test\r\n");
  
  // get_present_position(pos);
  // DEBUG_SERIAL.printf("time:%ld\r\n", startTime);
  // leg_test();
  // trot(startTime);

  // test();
}
