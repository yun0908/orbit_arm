﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QThread>
#include "canthread.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    CANsetting = new CANParamSetting();
    canthread = new CANThread();
    protocolHand = new ProtocolThrend();
    id1=this->startTimer(5);
    //    QThread thread;
    //    protocolHand->moveToThread(&thread);
    //    QObject::connect(canthread,&CANThread::getProtocolData,protocolHand,&ProtocolThrend::protocolHand);
    //    thread.start();


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()//参数设置
{
    CANsetting->show();
}

void MainWindow::on_pushButton_2_clicked()//启动CAN
{
    if(ui->pushButton_2->text() == tr("CAN启动"))
    {
        //ui->pushButton->setEnabled(false);
        ui->pushButton_2->setText(tr("CAN关闭"));
        canthread->deviceType = 4;
        canthread->debicIndex =0;
        canthread->baundRate = 1000;
        canthread->debicCom = 0;
        qDebug()<<canthread->deviceType
               <<canthread->debicIndex
              <<canthread->baundRate
             <<canthread->debicCom;
        bool dev = canthread->openCAN();
        if(dev == true)
            canthread->start();
    }
    else if(ui->pushButton_2->text() == tr("CAN关闭"))
    {
        //ui->pushButton->setEnabled(true);
        ui->pushButton_2->setText(tr("CAN启动"));
        canthread->stop();
        canthread->closeCAN();
    }
}


/******************************************************自写******************************************************/


void MainWindow::on_pushButton_5_clicked()
{
    static uint8_t send_flag = 1;
    if(send_flag == true){

        send_flag = false;
    }else{
        killTimer(id1);
        send_flag = true;
    }

}
void MainWindow::handleTimer()
{
    qDebug()<<"killtime";
    killTimer(id1);
}

void MainWindow::timerEvent(QTimerEvent *event)
{
    //    static  uint id = 0;
    //    static  uint8_t data[5] = {0};
    //    if(event->timerId() == id1)
    //    {
    //        if(id< 10){
    //            id++;
    //        }else{
    //            id = 1;
    //            static  uint index = 0;
    //            int32_t speed=2000 * sin((2 * 3.14 * index++)/1000);if(index>1000){index=0;}
    //            data[0] = 0X1D;
    //            data[1] = speed&0xff;
    //            data[2] = (speed>>8)&0xff;
    //            data[3] = (speed>>16)&0xff;
    //            data[4] = (speed>>24)&0xff;

    //            qDebug()<< speed
    //                    <<data[1]
    //                   <<data[2]
    //                  <<data[3]
    //                 <<data[4];
    //        }
    //        canthread->sendDatamy(id,data,5);
    //    }


    if(event->timerId() == id1){
        if(newbp_flag == 1){
            static  uint id = 0;
            if(id < 10){        id++;    }else{     id=1;   }
            static  uint8_t data[5] = {0};
            static int32_t datebuff[10],Lastdatebuff[10];
            datebuff[id] = 0;
            switch (runmode) {
            case 0:{//复位
                data[0] = 0X1E;

                Lastdatebuff[id] = 0;
                qDebug()<<"复位"<<id;
            }break;
            case 0xFF:{//停止
                data[0] = 0X1d;

                Lastdatebuff[id] = 0;
                qDebug()<<"停止"<<id;
            }break;

            case 1:{//1、3复位
                data[0] = 0X1E;

                if(id%2 == 1){
                    Lastdatebuff[id] = 0;
                    qDebug()<<"1、3复位id"<<id;
                }

            }break;
            case 2:{//2、4复位
                data[0] = 0X1E;

                if(id%2 == 0){
                    Lastdatebuff[id] = 0;
                    qDebug()<<"2、4复位id"<<id;
                }
            }break;
            case 3:{//1、3   ++90
                data[0] = 0X1E;

                if(id%2 == 1){
                    datebuff[id] = ( (101*65536)*90) / 360;
                    qDebug()<<"单+90id"<<id;
                }


            }break;
            case 4:{//1、3   --90
                data[0] = 0X1E;

                if(id%2 == 1){
                    datebuff[id] = -( (101*65536)*90) / 360;
                    qDebug()<<"单-90id"<<id;
                }
            }break;
            case 5:{//2、4   ++90
                data[0] = 0X1E;

                if(id%2 == 0){
                    datebuff[id] = ( (101*65536)*90) / 360;
                    qDebug()<<"偶+90id"<<id;
                }
            }break;
            case 6:{//2、4   --90
                data[0] = 0X1E;
                if(id%2 == 0){
                    datebuff[id] = -( (101*65536)*90) / 360;
                    qDebug()<<"偶-90id"<<id;
                }
            }break;
            }
            Lastdatebuff[id] = Lastdatebuff[id] + datebuff[id];

            data[1] = Lastdatebuff[id] & 0xff;
            data[2] = (Lastdatebuff[id]>>8)&0xff;
            data[3] = (Lastdatebuff[id]>>16)&0xff;
            data[4] = (Lastdatebuff[id]>>24)&0xff;
            canthread->sendDatamy(id,data,5);

            if(id == 10){newbp_flag = 0;}
        }
    }
}
void MainWindow::on_bp_0_clicked()
{
    newbp_flag = 1;
    runmode = 0;
}
void MainWindow::on_bp_stop_clicked()
{
    newbp_flag = 1;
    runmode = 0XFF;
}
//单
void MainWindow::on_bp_13_clicked()
{
    newbp_flag = 1;
    runmode = 1;
}

void MainWindow::on_bp_1_clicked()
{
    newbp_flag = 1;
    runmode = 3;
}

void MainWindow::on_bp_2_clicked()
{
    newbp_flag = 1;
    runmode = 4;
}
//偶
void MainWindow::on_bp_24_clicked()
{
    newbp_flag = 1;
    runmode = 2;
}

void MainWindow::on_pb_3_clicked()
{
    newbp_flag = 1;
    runmode = 5;
}

void MainWindow::on_bp_4_clicked()
{
    newbp_flag = 1;
    runmode = 6;
}




