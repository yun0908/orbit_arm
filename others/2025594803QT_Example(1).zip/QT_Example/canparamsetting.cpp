﻿#include "canparamsetting.h"
#include "ui_canparamsetting.h"
#include <QFile>
#include <QDebug>

CANParamSetting::CANParamSetting(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CANParamSetting)
{
    ui->setupUi(this);

    QFile file("canparamsetting.qss");
    if( file.open(QFile::ReadOnly))
    {
        QString styleSheet = QLatin1String(file.readAll());
//        qDebug()<<styleSheet.remove("\r").remove("\n").remove("\t");
        this->setStyleSheet(styleSheet);
        file.close();
        qDebug()<<"load success";
    }
    else
        qDebug()<<"load error";
}

CANParamSetting::~CANParamSetting()
{
    delete ui;
}

void CANParamSetting::on_pushButton_clicked()//确定
{
    CANtype = 4;//ui->baundRate->currentIndex();
    index = ui->index->currentIndex();
    baundRate = (int)ui->baundRate->currentText().remove("Kbps").toFloat();
    devicCOM = ui->CANCom->currentIndex();
    this->hide();
}

void CANParamSetting::on_pushButton_2_clicked()//退出
{
    this->hide();
}
