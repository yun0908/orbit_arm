/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *bp_13;
    QPushButton *bp_stop;
    QPushButton *bp_24;
    QPushButton *bp_0;
    QPushButton *bp_1;
    QPushButton *pb_3;
    QPushButton *bp_2;
    QPushButton *bp_4;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(641, 304);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(512, 32, 80, 29));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy);
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 40, 80, 29));
        sizePolicy.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy);
        bp_13 = new QPushButton(centralWidget);
        bp_13->setObjectName(QString::fromUtf8("bp_13"));
        bp_13->setGeometry(QRect(40, 110, 80, 29));
        sizePolicy.setHeightForWidth(bp_13->sizePolicy().hasHeightForWidth());
        bp_13->setSizePolicy(sizePolicy);
        bp_stop = new QPushButton(centralWidget);
        bp_stop->setObjectName(QString::fromUtf8("bp_stop"));
        bp_stop->setGeometry(QRect(140, 40, 81, 31));
        bp_24 = new QPushButton(centralWidget);
        bp_24->setObjectName(QString::fromUtf8("bp_24"));
        bp_24->setGeometry(QRect(40, 150, 80, 29));
        sizePolicy.setHeightForWidth(bp_24->sizePolicy().hasHeightForWidth());
        bp_24->setSizePolicy(sizePolicy);
        bp_0 = new QPushButton(centralWidget);
        bp_0->setObjectName(QString::fromUtf8("bp_0"));
        bp_0->setGeometry(QRect(40, 70, 81, 31));
        bp_1 = new QPushButton(centralWidget);
        bp_1->setObjectName(QString::fromUtf8("bp_1"));
        bp_1->setGeometry(QRect(130, 110, 80, 29));
        sizePolicy.setHeightForWidth(bp_1->sizePolicy().hasHeightForWidth());
        bp_1->setSizePolicy(sizePolicy);
        pb_3 = new QPushButton(centralWidget);
        pb_3->setObjectName(QString::fromUtf8("pb_3"));
        pb_3->setGeometry(QRect(130, 150, 80, 29));
        sizePolicy.setHeightForWidth(pb_3->sizePolicy().hasHeightForWidth());
        pb_3->setSizePolicy(sizePolicy);
        bp_2 = new QPushButton(centralWidget);
        bp_2->setObjectName(QString::fromUtf8("bp_2"));
        bp_2->setGeometry(QRect(220, 110, 80, 29));
        sizePolicy.setHeightForWidth(bp_2->sizePolicy().hasHeightForWidth());
        bp_2->setSizePolicy(sizePolicy);
        bp_4 = new QPushButton(centralWidget);
        bp_4->setObjectName(QString::fromUtf8("bp_4"));
        bp_4->setGeometry(QRect(220, 150, 80, 29));
        sizePolicy.setHeightForWidth(bp_4->sizePolicy().hasHeightForWidth());
        bp_4->setSizePolicy(sizePolicy);
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "CAN\345\217\202\346\225\260\350\256\276\347\275\256", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "CAN\345\220\257\345\212\250", nullptr));
        bp_13->setText(QCoreApplication::translate("MainWindow", "\345\244\215\344\275\2151\343\200\2013", nullptr));
        bp_stop->setText(QCoreApplication::translate("MainWindow", "\345\201\234\346\255\242", nullptr));
        bp_24->setText(QCoreApplication::translate("MainWindow", "\345\244\215\344\275\2152\343\200\2014", nullptr));
        bp_0->setText(QCoreApplication::translate("MainWindow", "\345\244\215\344\275\215", nullptr));
        bp_1->setText(QCoreApplication::translate("MainWindow", "-90", nullptr));
        pb_3->setText(QCoreApplication::translate("MainWindow", "-90", nullptr));
        bp_2->setText(QCoreApplication::translate("MainWindow", "+90", nullptr));
        bp_4->setText(QCoreApplication::translate("MainWindow", "+90", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
