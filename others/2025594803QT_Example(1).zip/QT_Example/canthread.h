﻿#ifndef CANTHREAD_H
#define CANTHREAD_H

#include <QThread>
#include "ControlCAN.h"
#include <QDebug>

class CANThread:public QThread
{
    Q_OBJECT
public:
    CANThread();

    void stop();

    bool openCAN();

    void closeCAN();

    void sendData(int ID,unsigned char *ch);
    void sendDatamy(uint8_t id,uint8_t *data,uint8_t len);
    int deviceType;
    int debicIndex;
    int baundRate;
    int debicCom;

    bool stopped;

signals:
    void getProtocolData(VCI_CAN_OBJ *vci,DWORD dwRel);

private:
    void run();
    void sleep(unsigned int msec);

};

#endif // CANTHREAD_H
