﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ControlCAN.h"
#include <QDebug>
#include "canparamsetting.h"
#include "protocolthrend.h"
#include "canthread.h"
#include "QTimerEvent"
#include "math.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void  handleTimer();
    void  timerEvent(QTimerEvent *event);
    int id1,id2;
    int runmode;
    int newbp_flag=0;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();




    void on_pushButton_5_clicked();

    void on_bp_13_clicked();

    void on_bp_1_clicked();

    void on_bp_2_clicked();

    void on_bp_24_clicked();

    void on_pb_3_clicked();

    void on_bp_4_clicked();

    void on_bp_0_clicked();

    void on_bp_stop_clicked();

private:
    Ui::MainWindow *ui;
    CANParamSetting *CANsetting;
    CANThread *canthread;
    ProtocolThrend *protocolHand;
    QThread thread;
};

#endif // MAINWINDOW_H
